/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dicoapp;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.stream.Stream;
import javax.ws.rs.GET;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;


//@javax.ws.rs.Path("wordsearch")
@Produces("application/json")
public class DicoApp {
    private final String FILE_NAME = "dictionary.txt";
    private Path file = Paths.get(FILE_NAME);
    private List<String> anagram, kangaroo;
    
  /*
    @GET    
    @javax.ws.rs.Path("anagram/{word}/")
    public List<String> anagram(@PathParam("word")String word) { 
        if(!Files.exists(file)) {
            System.err.println("NoSuchFileException");
            return null;
        }
        anagram = new LinkedList<>();
        //System.out.println("Enter word");
        //Scanner input = new Scanner(System.in);
        //word = input.next().toLowerCase();
        char[] wordArray = word.toCharArray();
        Arrays.sort(wordArray);
        System.out.println(Instant.now());
            
        try (Stream<String> stream =  Files.lines(file);){            
            
            stream.forEach( e-> { 
                char[] eArray = e.toCharArray();
                Arrays.sort(eArray);
                if(Arrays.equals(wordArray, eArray))                
                    anagram.add(e);
            });
            System.out.println(Instant.now());
            System.out.println(anagram);
            
        }
        catch (IOException ioe) {
            ioe.printStackTrace();
        }

        return anagram;
    }
    @GET    
    @javax.ws.rs.Path("kangaroo/{word}/")
    public List<String> kangaroo(@PathParam("word")String word) { 
        if(!Files.exists(file)) {
            System.err.println("NoSuchFileException");
            return null;
        }
        kangaroo = new LinkedList<>();
        //System.out.println("Enter word");
        //Scanner input = new Scanner(System.in);
        //word = input.next().toLowerCase();
        char[] wordArray = word.toCharArray();
                
        
        try {
            System.out.println(Instant.now());
            Stream<String> stream =  Files.lines(file);            
            stream.forEach( e-> { 
               
                Queue<Character> eQueue = new LinkedList<>();
                char[] eArray = e.toCharArray();
                for(char c: eArray)
                    eQueue.add(c);
                
                for (char c: wordArray) {
                    if(!eQueue.isEmpty() && c == (char) eQueue.element())
                        eQueue.poll();
                }
                
                if(eQueue.isEmpty())
                    kangaroo.add(e);
               
            });
            System.out.println(Instant.now());
            System.out.println(kangaroo);
        }
        catch (IOException ioe) {
            ioe.printStackTrace();
        }
        return kangaroo;
    }
    @GET    
    @javax.ws.rs.Path("hasBackronym/")
    public  boolean hasBackronym(@javax.ws.rs.QueryParam("word")String word) { 
        if(!Files.exists(file)) {
            System.err.println("NoSuchFileException");
            return false;
        }
        boolean hasBackronym = false;
        //System.out.println("Enter word");
        //Scanner input = new Scanner(System.in);
        //word = input.next().toLowerCase();
        
        String temp="";
        for(int i = 1; i <= word.length(); i++)
            temp += word.charAt(word.length()-i);
        final String reverse = temp;
        System.out.println("reverse: " + reverse);
        System.out.println(Instant.now());
        try (Stream<String> stream =  Files.lines(file);){
            hasBackronym = stream.anyMatch(e -> e.equals(reverse));
            System.out.println(Instant.now());
            //System.out.println("Has backronym: "+ hasBackronym);
        }
        catch (IOException ioe) {
            ioe.printStackTrace();
        }

        return hasBackronym;
    }
*/
    @GET
    @javax.ws.rs.Path("test/")
    public String test(){
        
        return "Successful";
    }
}
