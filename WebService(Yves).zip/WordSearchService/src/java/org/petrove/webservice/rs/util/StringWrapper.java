/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.petrove.webservice.rs.util;

import com.sun.xml.rpc.processor.modeler.j2ee.xml.javaIdentifierType;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement
public class StringWrapper implements java.io.Serializable,  CharSequence{

    public StringWrapper() {
        this.value="";
    }

    public StringWrapper(String value) {
        this.value = value;
    }
    
    private String value;
    @Override
    public int length() {
        return value.length();
    }

    @Override
    public char charAt(int index) {
        return value.charAt(index);
    }

    @Override
    public CharSequence subSequence(int start, int end) {
        return value.subSequence(end, end);
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    
    @Override
    public String toString() {
        return value;
    }
    
    
}
