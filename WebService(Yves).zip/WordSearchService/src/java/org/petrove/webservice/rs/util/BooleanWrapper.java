/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.petrove.webservice.rs.util;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class BooleanWrapper implements java.io.Serializable {
    private boolean value;

    public BooleanWrapper() {
        value=false;
    }

    public BooleanWrapper(boolean value) {
        this.value = value;
    }
    
    public BooleanWrapper(String value) {
        this.value = new Boolean(value);
    }

    public boolean isValue() {
        return value;
    }

    public void setValue(boolean value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return value+"";
    }
    
    
    
}
