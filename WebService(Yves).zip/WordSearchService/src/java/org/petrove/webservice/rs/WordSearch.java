/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.petrove.webservice.rs;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Stream;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.ws.rs.GET;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import org.petrove.webservice.rs.util.BooleanWrapper;
import org.petrove.webservice.rs.util.StringWrapper;

@javax.ws.rs.Path("wordsearch")
//@Produces("application/json")
public class WordSearch {
    private final String FILE_NAME = "C:/dictionary.txt";
    private Path file = Paths.get(FILE_NAME);
    InputStream stream = null;
    private List<StringWrapper> anagram, kangaroo;
    private static Map<String, String> dictionaries;
    
    static {
        dictionaries = new HashMap<>();
        dictionaries.put("en", "words.txt");
        dictionaries.put("fr", "francais.txt");
        dictionaries.put("es", "espanol.txt");
        dictionaries.put("pt", "porto.txt");        
    }
    public WordSearch() {
        
    }
    
    
  
    @GET    
    @javax.ws.rs.Path("anagram/{language}/{word}")
    @Produces(MediaType.APPLICATION_JSON)
    public List<StringWrapper> anagram(@PathParam("word")String word, @PathParam("language")String language) {
        System.out.println((int)'a');
        try { 
             URL url = this.getClass().getResource(dictionaries.get(language));
             file = Paths.get(url.toURI());
            System.out.println("==file:"+ file.getFileName());
            
        } catch (Exception ex) {
            Logger.getLogger(WordSearch.class.getName()).log(Level.SEVERE, null, ex);
        }
        word = word.toLowerCase();
        if(!Files.exists(file)) {
            System.err.println("NoSuchFileException");
            Thread.currentThread().getContextClassLoader().getResource("dictionary");
            return null;
        }
        anagram = new ArrayList<>();
        //System.out.println("Enter word");
        //Scanner input = new Scanner(System.in);
        //word = input.next().toLowerCase();
        char[] wordArray = word.toCharArray();
        Arrays.sort(wordArray);
        System.out.println(Instant.now());
        
        try (Stream<String> stream =  Files.lines(file);){            
            
            stream.forEach( e-> { 
                char[] eArray = e.toLowerCase().toCharArray();
                Arrays.sort(eArray);
                if(Arrays.equals(wordArray, eArray))                
                    anagram.add(new StringWrapper(e));
            });
            System.out.println(Instant.now());
            System.out.println(anagram);
            
        }
        catch (IOException ioe) {
            ioe.printStackTrace();
        }

        return anagram;
    }
    @GET    
    @javax.ws.rs.Path("kangaroo/{language}/{word}/")
    @Produces({MediaType.APPLICATION_JSON})
    public List<StringWrapper> kangaroo(@PathParam("word")String word,@PathParam("language") String language) { 
        System.out.println("========Word:"+word +" =======language:"+language);
        try { 
             URL url = this.getClass().getResource(dictionaries.get(language));
             System.out.println("==pass 1:"+url);
             file = Paths.get(url.toURI());
             System.out.println("==pass 2:"+file);
            System.out.println("==file:"+ file.getFileName());
            
        } catch (Exception ex) {
            Logger.getLogger(WordSearch.class.getName()).log(Level.SEVERE, null, ex);
        }
        //word = word.toLowerCase();
        if(!Files.exists(file)) {
            System.err.println("NoSuchFileException");
            return null;
        }
        kangaroo = new LinkedList<>();
        //System.out.println("Enter word");
        //Scanner input = new Scanner(System.in);
        //word = input.next().toLowerCase();
        char[] wordArray = word.toCharArray();
                
        
        try {
            System.out.println(Instant.now());
            Stream<String> stream =  Files.lines(file);            
            stream.forEach( e-> { 
               
                Queue<Character> eQueue = new LinkedList<>();
                char[] eArray = e.toLowerCase().toCharArray();
                for(char c: eArray)
                    eQueue.add(c);                
                for (char c: wordArray) {
                    if(!eQueue.isEmpty() && c == (char) eQueue.element())
                        eQueue.poll();
                        
                }
                
                if(eQueue.isEmpty())
                    kangaroo.add(new StringWrapper(e));
               
            });
            System.out.println(Instant.now());
            System.out.println(kangaroo);
        }
        catch (IOException ioe) {
            ioe.printStackTrace();
        }
        return kangaroo;
    }
    @GET    
    @javax.ws.rs.Path("backronym/{language}/{word}")
    @Produces("application/json")
    public  BooleanWrapper hasBackronym(@PathParam("word")String word, @PathParam("language")String language) { 
        try { 
             URL url = this.getClass().getResource(dictionaries.get(language));
             file = Paths.get(url.toURI());
            System.out.println("==file:"+ file.getFileName());
            
        } catch (Exception ex) {
            Logger.getLogger(WordSearch.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        word = word.toLowerCase();
        if(!Files.exists(file)) {
            System.err.println("NoSuchFileException");
            return new BooleanWrapper(false);
        }
        boolean hasBackronym = false;
        
        
        String temp="";
        for(int i = 1; i <= word.length(); i++)
            temp += word.charAt(word.length()-i);
        final String reverse = temp;
        System.out.println("reverse: " + reverse);
        System.out.println(Instant.now());
        try (Stream<String> stream =  Files.lines(file);){
            hasBackronym = stream.anyMatch(e -> e.equalsIgnoreCase(reverse));
            System.out.println(Instant.now());
            //System.out.println("Has backronym: "+ hasBackronym);
        }
        catch (IOException ioe) {
            ioe.printStackTrace();
        }

        return new BooleanWrapper(hasBackronym);
    }

    @GET
    @javax.ws.rs.Path("test/")
    public String test(){ 
        System.out.println("===rs/test accessed");
        return "success";
    }
}
