package org.petrove.wordsearch;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;

public class BatteryMonitor {
    private Context context;
    private Intent batteryStatus;

    public BatteryMonitor(Context context) {
        this.context = context;
        IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        batteryStatus = context.registerReceiver(null, ifilter);
    }

    public int getBatteryStatus() {
        return batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
    }

    public String getBatteryStatusAsString() {
        int status = getBatteryStatus();
        switch (status) {
            case BatteryManager.BATTERY_STATUS_NOT_CHARGING :
                return "NOT CHARGING";
            case BatteryManager.BATTERY_STATUS_DISCHARGING :
                return "DISCHARGING";
            case BatteryManager.BATTERY_STATUS_CHARGING :
                return "CHARGING";
            case BatteryManager.BATTERY_STATUS_FULL :
                return "FULL";
            case BatteryManager.BATTERY_STATUS_UNKNOWN :
                return "UNKNOWN";
            default:
                return "UNEXPECTED";
        }
    }

    public int getBatteryLevel() {
        return batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
    }

    public boolean batteryIsLow() {
        String batteryStatus = getBatteryStatusAsString();
        if(batteryStatus.equals("FULL") || batteryStatus.equals("CHARGING"))
            return false;
        return getBatteryLevel() < 15;
    }
}
