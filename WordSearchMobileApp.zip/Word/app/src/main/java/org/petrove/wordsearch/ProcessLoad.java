package org.petrove.wordsearch;

import java.util.HashMap;
import java.util.Map;

public class ProcessLoad {
    public static final int ANAGRAM_WORD_LOAD = 4,
            KANGAROO_WORD_LOAD = 3,
            BACKRONYM_WORD_LOAD = 2;
    public static final int HEAVY_LOAD = 500;
    public static  Map<String, Integer> LANGUAGE_LOAD;

    static {
        LANGUAGE_LOAD = new HashMap<String, Integer>();
        LANGUAGE_LOAD.put(TaskManager.ENGLISH, 47);
        LANGUAGE_LOAD.put(TaskManager.FRENCH, 22);
        LANGUAGE_LOAD.put(TaskManager.SPANISH, 18);
    }

    public static int calculateProcessLoad(String word, String option, String language) {
        if (option.equals(TaskManager.ANAGRAM)) {
            return anagramLoad(word, language);
        }
        else if(option.equals(TaskManager.KANGAROO)) {
            return kangarooLoad(word, language);
        }
        else if(option.equals(TaskManager.BACKRONYM)) {
            return backronymLoad(word, language);
        }
        else
            return -1;
    }

    private static int  anagramLoad(String word, String languge) {
        Integer results = LANGUAGE_LOAD.get(languge);
        if(results == null || results==0)
            return -1;

        return results * ANAGRAM_WORD_LOAD * 26 * word.length() / 6;
    }

    private static int  kangarooLoad(String word, String languge) {
        Integer results = LANGUAGE_LOAD.get(languge);
        if(results == null || results==0)
            return -1;
        return results * KANGAROO_WORD_LOAD * 26 * word.length() / 6;
    }

    private static int backronymLoad(String word, String languge) {
        Integer results = LANGUAGE_LOAD.get(languge);
        if(results == null || results==0)
            return -1;
        int temp = word.toLowerCase().charAt(word.length()-1)-95;
        temp = temp <=26?temp : 26;
        temp = temp > 0 ?temp : 1;
        return results * BACKRONYM_WORD_LOAD * temp * word.length() / 6;
    }
}
