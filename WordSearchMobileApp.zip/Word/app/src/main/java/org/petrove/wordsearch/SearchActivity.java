package org.petrove.wordsearch;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;

import android.content.DialogInterface;
import android.os.Bundle;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

public class SearchActivity extends Activity {
    private Context context = this;
    private Dialog progressDialog, resultDialog, cancelSearchDialog, logDialog;
    private LinearLayout layout;
    private ProgressBar progressBar;

    @Override
    protected void onStop() {
        Log.d("TaskManager", "onStop");
        TaskManager.persistDefaultLog(this);
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        Log.d("TaskManager", "onDestroy");
        TaskManager.persistDefaultLog(this);
        super.onDestroy();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_search);
        Button searchButton = (Button) findViewById(R.id.search);
        searchButton.setOnClickListener(searchListener);
        TextView output = (TextView) findViewById(R.id.output);
        output.setText("");
        try {
            Log.d("TaskManager", "=======files: "+ Arrays.asList(fileList()));
            TaskManager.loadDefLog(this);
            Log.d("TaskManager", "=======log loaded "+ org.petrove.wordsearch.Log.defaultLog());
        }
        catch (Exception e) {
            Log.d("TaskManager", "+===+cannot load log");
            e.printStackTrace();
        }

    }

    public void updateMenu(ScrollView scrollView) {
        TextView valueLabel;
        String textValue;
        Integer count;
        Long time;
        TaskManager.loadStats(context);
        valueLabel = (TextView) scrollView.findViewById(R.id.local_anagram_value);
        time = TaskManager.searchTime.get(TaskManager.LOCAL_ANAGRAM);
        if (time == null)
            time = 0L;
        count = TaskManager.searchCount.get(TaskManager.LOCAL_ANAGRAM);
        if (count == null)
            count = 0;
        textValue = (time / 1000.0) + " sec (" + count + " time(s))";
        valueLabel.setText(textValue);

        valueLabel = (TextView) scrollView.findViewById(R.id.local_kangaroo_value);
        time = TaskManager.searchTime.get(TaskManager.LOCAL_KANGAROO);
        if (time == null)
            time = 0L;
        count = TaskManager.searchCount.get(TaskManager.LOCAL_KANGAROO);
        if (count == null)
            count = 0;
        textValue = (time / 1000.0) + " sec (" + count + " time(s))";
        valueLabel.setText(textValue);

        valueLabel = (TextView) scrollView.findViewById(R.id.local_backronym_value);
        time = TaskManager.searchTime.get(TaskManager.LOCAL_BACKRONYM);
        if (time == null)
            time = 0L;
        count = TaskManager.searchCount.get(TaskManager.LOCAL_BACKRONYM);
        if (count == null)
            count = 0;
        textValue = (time / 1000.0) + " sec (" + count + " time(s))";
        valueLabel.setText(textValue);

        valueLabel = (TextView) scrollView.findViewById(R.id.local_average_value);
        time = TaskManager.searchTime.get(TaskManager.LOCAL_AVERAGE);
        if (time == null)
            time = 0L;
        count = TaskManager.searchCount.get(TaskManager.LOCAL_AVERAGE);
        if (count == null)
            count = 0;
        textValue = (time / 1000.0) + " sec (" + count + " time(s))";
        valueLabel.setText(textValue);


        valueLabel = (TextView) scrollView.findViewById(R.id.remote_anagram_value);
        time = TaskManager.searchTime.get(TaskManager.REMOTE_ANAGRAM);
        if (time == null)
            time = 0L;
        count = TaskManager.searchCount.get(TaskManager.REMOTE_ANAGRAM);
        if (count == null)
            count = 0;
        textValue = (time / 1000.0) + " sec (" + count + " time(s))";
        valueLabel.setText(textValue);

        valueLabel = (TextView) scrollView.findViewById(R.id.remote_kangaroo_value);
        time = TaskManager.searchTime.get(TaskManager.REMOTE_KANGAROO);
        if (time == null)
            time = 0L;
        count = TaskManager.searchCount.get(TaskManager.REMOTE_KANGAROO);
        if (count == null)
            count = 0;
        textValue = (time / 1000.0) + " sec (" + count + " time(s))";
        valueLabel.setText(textValue);

        valueLabel = (TextView) scrollView.findViewById(R.id.remote_backronym_value);
        time = TaskManager.searchTime.get(TaskManager.REMOTE_BACKRONYM);
        if (time == null)
            time = 0L;
        count = TaskManager.searchCount.get(TaskManager.REMOTE_BACKRONYM);
        if (count == null)
            count = 0;
        textValue = (time / 1000.0) + " sec (" + count + " time(s))";
        valueLabel.setText(textValue);

        valueLabel = (TextView) scrollView.findViewById(R.id.remote_average_value);
        time = TaskManager.searchTime.get(TaskManager.REMOTE_AVERAGE);
        if (time == null)
            time = 0L;
        count = TaskManager.searchCount.get(TaskManager.REMOTE_AVERAGE);
        if (count == null)
            count = 0;
        textValue = (time / 1000.0) + " sec (" + count + " time(s))";
        valueLabel.setText(textValue);


        valueLabel = (TextView) scrollView.findViewById(R.id.overall_anagram_value);
        time = TaskManager.searchTime.get(TaskManager.OVERALL_ANAGRAM);
        if (time == null)
            time = 0L;
        count = TaskManager.searchCount.get(TaskManager.OVERALL_ANAGRAM);
        if (count == null)
            count = 0;
        textValue = (time / 1000.0) + " sec (" + count + " time(s))";
        valueLabel.setText(textValue);

        valueLabel = (TextView) scrollView.findViewById(R.id.overall_kangaroo_value);
        time = TaskManager.searchTime.get(TaskManager.OVERALL_KANGAROO);
        if (time == null)
            time = 0L;
        count = TaskManager.searchCount.get(TaskManager.OVERALL_KANGAROO);
        if (count == null)
            count = 0;
        textValue = (time / 1000.0) + " sec (" + count + " time(s))";
        valueLabel.setText(textValue);

        valueLabel = (TextView) scrollView.findViewById(R.id.overall_backronym_value);
        time = TaskManager.searchTime.get(TaskManager.OVERALL_BACKRONYM);
        if (time == null)
            time = 0L;
        count = TaskManager.searchCount.get(TaskManager.OVERALL_BACKRONYM);
        if (count == null)
            count = 0;
        textValue = (time / 1000.0) + " sec (" + count + " time(s))";
        valueLabel.setText(textValue);

        valueLabel = (TextView) scrollView.findViewById(R.id.overall_average_value);
        time = TaskManager.searchTime.get(TaskManager.OVERALL_AVERAGE);
        if (time == null)
            time = 0L;
        count = TaskManager.searchCount.get(TaskManager.OVERALL_AVERAGE);
        if (count == null)
            count = 0;
        textValue = (time / 1000.0) + " sec (" + count + " time(s))";
        valueLabel.setText(textValue);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.search, menu);

        MenuItem menuLog = (MenuItem) menu.findItem(R.id.action_log);
        menuLog.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                Dialog dialog = new Dialog(context);
                updateLogDialog(dialog);
                return true;
            }
        });
        MenuItem menuStats = (MenuItem) menu.findItem(R.id.action_stats);
        MenuItem.OnMenuItemClickListener statsListener = new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                final Dialog d = new Dialog(context);
                d.setTitle("Average running time");
                final ScrollView scrollView = new ScrollView(d.getContext());
                scrollView.addView(getLayoutInflater().inflate(R.layout.statistics, null));
                d.setContentView(scrollView);

                Button cancelButton = (Button) scrollView.findViewById(R.id.stats_cancel);
                cancelButton.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        d.dismiss();
                    }
                });
                Button reset =(Button)scrollView.findViewById(R.id.stats_reset);
                reset.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        if(TaskManager.searchCountPreferences == null)
                            TaskManager.searchCountPreferences = context.getSharedPreferences(TaskManager.SEARCH_COUNT_KEY, Context.MODE_PRIVATE);
                        if(TaskManager.searchTimePreferences == null)
                            TaskManager.searchTimePreferences = context.getSharedPreferences(TaskManager.SEARCH_TIME_KEY, Context.MODE_PRIVATE);
                        TaskManager.searchCountPreferences.edit().clear().commit();
                        TaskManager.searchTimePreferences.edit().clear().commit();
                        TaskManager.searchCount.clear();
                        TaskManager.searchTime.clear();

                        updateMenu(scrollView);
                    }
                });


                updateMenu(scrollView);
                d.show();
                return true;
            }
        };
        menuStats.setOnMenuItemClickListener(statsListener);

        MenuItem menuItem = (MenuItem) menu.findItem(R.id.action_settings);


        MenuItem.OnMenuItemClickListener listener = new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                Dialog d = new Dialog(context);
                d.setTitle("Settings");
                final LinearLayout dialogLayout = new LinearLayout(d.getContext());
                dialogLayout.setOrientation(LinearLayout.VERTICAL);
                CheckBox cb = new CheckBox(dialogLayout.getContext());
                cb.setText("Authorize offload");
                cb.setChecked(TaskManager.isOffloadingAuthorized());
                cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                        TaskManager.setOffloadingAuthorized(b);
                        CheckBox c = (CheckBox) dialogLayout.getChildAt(1);
                        c.setEnabled(b);
                        if (b == false) {
                            TaskManager.setOffloadOnly(b);
                            c.setChecked(b);

                        }

                        Log.d("RTE", "" + TaskManager.isOffloadingAuthorized());
                    }
                });

                dialogLayout.addView(cb);
                cb = new CheckBox(dialogLayout.getContext());
                cb.setText("Use offload only");
                cb.setChecked(TaskManager.isOffloadOnly());
                cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                        TaskManager.setOffloadOnly(b);
                        Log.d("RTE", "" + TaskManager.isOffloadOnly());
                    }
                });
                dialogLayout.addView(cb);
                d.setContentView(dialogLayout);
                d.show();
                return true;
            }
        };
        menuItem.setOnMenuItemClickListener(listener);
        return true;
    }

    private void updateLogDialog(final Dialog dialog) {
        dialog.setTitle("Log");
        ScrollView scv = new ScrollView(dialog.getContext());
        dialog.setContentView(scv);
        LinearLayout lay = new LinearLayout(context);
        lay.setOrientation(LinearLayout.VERTICAL);
        LinearLayout l;
        int index =0;
        for(org.petrove.wordsearch.Log.Entry logEntry:
                org.petrove.wordsearch.Log.defaultLog().entryList()) {
            l= (LinearLayout) getLayoutInflater().inflate(R.layout.log_entry, null);
            lay.addView(l);
            TextView view = (TextView) l.findViewById(R.id.entry);
            view.append(" "+ index++);

            view = (TextView) l.findViewById(R.id.word_value);
            view.setText(logEntry.getWord());

            view = (TextView) l.findViewById(R.id.language_value);
            view.setText(logEntry.getLanguage());

            view = (TextView) l.findViewById(R.id.option_value);
            view.setText(logEntry.getSearchOption());

            view = (TextView) l.findViewById(R.id.mode_value);
            view.setText(logEntry.getMode().toString());

            view = (TextView) l.findViewById(R.id.duration_value);
            view.setText(logEntry.getTimeInMilli()/1000.0+"");

            view = (TextView) l.findViewById(R.id.load_value);
            view.setText(logEntry.getLoad()+"");

            view = (TextView) l.findViewById(R.id.found_value);
            view.setText(logEntry.getFound()+"");

            view = (TextView) l.findViewById(R.id.reason_value);
            view.setText(logEntry.getReason());
        }

        l= (LinearLayout) getLayoutInflater().inflate(R.layout.button_layout, null);
        Button clear = (Button) l.findViewById(R.id.report);
        clear.setText("Clear");
        clear.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                org.petrove.wordsearch.Log.defaultLog().entryList().clear();
                TaskManager.persistDefaultLog(context);
                dialog.dismiss();
                updateLogDialog(new Dialog(context));

            }
        });
        Button back = (Button) l.findViewById(R.id.back);
        back.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        lay.addView(l);
        scv.addView(lay);
        dialog.show();
    }
    private OnClickListener searchListener = new OnClickListener() {
        private ArrayList<View> textViewList;

        @Override
        public void onClick(View view) {
            createResultDialog();
            createProgressDialog();
            progressDialog.show();
            Log.d("SearchActivity", "start");
            ListView listView = (ListView) findViewById(R.id.expandableList);
            textViewList = new ArrayList<View>();

            TextView output = (TextView) findViewById(R.id.output);
            CheckBox anagramBox = (CheckBox) findViewById(R.id.anagramBox);
            CheckBox kangarooBox = (CheckBox) findViewById(R.id.kangarooBox);
            CheckBox backronymBox = (CheckBox) findViewById(R.id.backronymBox);

            CheckBox englishBox = (CheckBox) findViewById(R.id.englishBox);
            CheckBox frenchBox = (CheckBox) findViewById(R.id.frenchBox);
            CheckBox spanishBox = (CheckBox) findViewById(R.id.spanishBox);
            //CheckBox portugueseBox = (CheckBox) findViewById(R.id.portugueseBox);
            Log.d("SearchActivity", "ready to search");
            Date start = new Date();
            // Log.d("Search Button", "button clicked");

            EditText wordInput = (EditText) findViewById(R.id.wordInput);
            String word = wordInput.getText().toString().toLowerCase();
            if (word == null)
                word = "";
            Log.d("Word outside:", word);
            ArrayList<String> languages = new ArrayList<String>(), search = new ArrayList<String>();

            if (englishBox.isChecked())
                languages.add(TaskManager.ENGLISH);
            if (frenchBox.isChecked())
                languages.add(TaskManager.FRENCH);
            if (spanishBox.isChecked())
                languages.add(TaskManager.SPANISH);


            if (kangarooBox.isChecked())
                search.add(TaskManager.KANGAROO);
            if (backronymBox.isChecked())
                search.add(TaskManager.BACKRONYM);
            if (anagramBox.isChecked())
                search.add(TaskManager.ANAGRAM);

            boolean valid = ((englishBox.isChecked() || frenchBox.isChecked() || spanishBox.isChecked())
                && (kangarooBox.isChecked() || backronymBox.isChecked() || anagramBox.isChecked())
                && (!word.equals("")));

            if(!valid) {
                progressDialog.dismiss();
                return;
            }
            Log.d("SearchActivity", "launching activity for word:-");
            final TaskManager task = new TaskManager(
                    word,
                    languages.toArray(new String[0]),
                    search.toArray(new String[0]),
                    context,
                    progressDialog,
                    progressBar,
                    resultDialog,
                    layout);
            task.execute();
            progressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                @Override
                public void onCancel(DialogInterface dialogInterface) {
                    final Dialog dial = new Dialog(context);
                    dial.setTitle("Cancel search");
                    LinearLayout l = new LinearLayout(dial.getContext());
                    l.setOrientation(LinearLayout.VERTICAL);
                    TextView txt = new TextView(l.getContext());
                    txt.setText("Do you wanna cancel the search?");
                    l.addView(txt);
                    LinearLayout l2 = (LinearLayout)LayoutInflater.from(l.getContext()).inflate(R.layout.button_layout,null);
                    l.addView(l2);
                    Button cancel = (Button) l2.findViewById(R.id.report);
                    cancel.setText("Abort");
                    cancel.setOnClickListener(new OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Iterator<Executor> iterator = task.getProcesses().iterator();
                            Executor executor;
                            while(iterator.hasNext() ) {
                                executor = iterator.next();
                                if(!executor.isResultReady()) {
                                    executor.abort();
                                    iterator.remove();
                                    Log.d("Task", "===============aborted");
                                }
                            }
                            dial.dismiss();

                        }
                    });
                    Button cont = (Button) l2.findViewById(R.id.back);
                    cont.setText("Continue");
                    cont.setOnClickListener(new OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            dial.dismiss();
                            progressDialog.show();
                        }
                    });
                    dial.setContentView(l);
                    dial.show();


                }
            });
        }
    };

    private void createProgressDialog() {


        progressDialog = new Dialog(this);

        progressDialog.setCancelable(true);
        progressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                Dialog cancelSearchDialog = new Dialog(context);
                cancelSearchDialog.setTitle("Do you wanna cancel the search?");


            }
        });
        progressDialog.setTitle("Waiting for results");
        progressBar = new ProgressBar(progressDialog.getContext(), null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        progressBar.setIndeterminate(false);


        LinearLayout l = new LinearLayout(progressDialog.getContext());
        l.setOrientation(LinearLayout.VERTICAL);
        l.addView(progressBar);
        progressDialog.setContentView(l);
        //progressDialog.getWindow().getAttributes().alpha =.5f;
        //progressDialog.getWindow().getAttributes().

    }

    private void createResultDialog() {
        resultDialog = new Dialog(context);
        ScrollView scroll = new ScrollView(resultDialog.getContext());
        layout = new LinearLayout(resultDialog.getContext());
        layout.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(layout);
        resultDialog.setContentView(scroll);
        resultDialog.setTitle("Results");
    }
}
