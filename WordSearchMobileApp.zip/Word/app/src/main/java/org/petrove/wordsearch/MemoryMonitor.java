package org.petrove.wordsearch;

import android.app.ActivityManager;
import android.content.Context;
import android.util.Log;

public class MemoryMonitor {
    private Context context;

    public MemoryMonitor(Context context) {
        this.context = context;
        //this.context.getSystemService(Context.ACTIVITY_SERVICE);
        Log.d("MemoryMonitor", "...created");
    }

    public long getAvailableMemory(){
        return getMemoryInfo().availMem;
    }

    public long getTotalMemory() {
        return getMemoryInfo().totalMem;
    }

    public boolean hasEnoughMemory() {
        return getMemoryInfo().lowMemory;
    }
    private ActivityManager.MemoryInfo getMemoryInfo() {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
        activityManager.getMemoryInfo(memoryInfo);
        //Log.d("MemoryMonitor", memoryInfo.toString());
        return memoryInfo;
    }
}
