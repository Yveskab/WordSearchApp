package org.petrove.wordsearch;

import android.content.Context;
import android.graphics.Color;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;
import java.util.concurrent.ExecutionException;

import static org.petrove.wordsearch.TaskManager.ANAGRAM;
import static org.petrove.wordsearch.TaskManager.ANAGRAM_EN;
import static org.petrove.wordsearch.TaskManager.ANAGRAM_ES;
import static org.petrove.wordsearch.TaskManager.ANAGRAM_FR;
import static org.petrove.wordsearch.TaskManager.BACKRONYM;
import static org.petrove.wordsearch.TaskManager.BACKRONYM_EN;
import static org.petrove.wordsearch.TaskManager.BACKRONYM_ES;
import static org.petrove.wordsearch.TaskManager.BACKRONYM_FR;
import static org.petrove.wordsearch.TaskManager.FRENCH;
import static org.petrove.wordsearch.TaskManager.KANGAROO;
import static org.petrove.wordsearch.TaskManager.KANGAROO_EN;
import static org.petrove.wordsearch.TaskManager.KANGAROO_ES;
import static org.petrove.wordsearch.TaskManager.KANGAROO_FR;
import static org.petrove.wordsearch.TaskManager.SPANISH;

public class LocalTaskExecutor extends AsyncTask<Object, Object, Object> implements Executor{
    private String word;
    private String language;
    private String searchOption;
    private String reason;
    private Boolean resultReady = false;
    private Context context;
    private Object result;
    private TaskManager task;
    private long startTime, endTime;
    public LocalTaskExecutor(String word, String language,
                             String searchOption, String reason, Context c, TaskManager task) {
        this.word = word;
        this.language = language;
        this.searchOption = searchOption;
        this.reason = reason;
        context = c;
        this.task = task;
        Log.d("LTE", "==Local task launched");
    }

    public List<String> searchForAnagram(String word, String language) {
        int load = ProcessLoad.calculateProcessLoad(word, ANAGRAM, language);
        Log.d("TaskManager ", word + " - " + ANAGRAM + " - " + language + " - " + load);
        Log.d("TaskManager", "anagram en - search start");
        List<String> anagram = new ArrayList<String>();
        char[] wordArray = word.toCharArray();
        Arrays.sort(wordArray);
        Log.d("TaskManager", "anag - ready to read");
        // InputStream in = getAssets().open("dictionary.txt");
        InputStream in = null;
        try {
            in = context.getAssets().open(language);
        }
        catch(IOException ioe) {
            Log.e("task", ioe.getLocalizedMessage());
        }

        Scanner input = new Scanner(in);
        Log.d("TaskManager", "anag - file read");
        while (input.hasNext()) {
            String e = input.nextLine();
            char[] eArray = e.toLowerCase().toCharArray();
            Arrays.sort(eArray);

            if (Arrays.equals(wordArray, eArray)) {
                anagram.add(e);
            }
        }
        synchronized (resultReady) {
            resultReady = true;
            return anagram;
        }
    }

    public List<String> searchForKangaroo(String word, String language) {
        int load = ProcessLoad.calculateProcessLoad(word, KANGAROO, language);
        Log.d("TaskManager ", word + " - " + KANGAROO + " - " + language + " - " + load);
        Log.d("TaskManager", language);
        Log.d("input Word kangaroo:", word);
        List<String> kangaroo = new ArrayList<String>();
        char[] wordArray = word.toCharArray();
        InputStream in = null;
        try {
            in = context.getAssets().open(language);
        }
        catch(IOException ioe) {
            Log.e("TaskManager", ioe.getLocalizedMessage());
        }
        Scanner input = new Scanner(in);

        while (input.hasNext()) {
            // Log.d("word", input.next());
            String e = input.nextLine();

            Queue<Character> eQueue = new LinkedList<Character>();
            char[] eArray = e.toLowerCase().toCharArray();
            for (char c : eArray)
                eQueue.add(c);

            for (char c : wordArray) {
                if (!eQueue.isEmpty() && c == (char) eQueue.element())
                    eQueue.poll();
            }
            if (eQueue.isEmpty()) {
                kangaroo.add(e);
                Log.d("kangaroo", e);
            }
        }
        synchronized (resultReady) {
            resultReady = true;
            return kangaroo;
        }
    }

    public Boolean hasBackronym(String word, String language) {
        int load = ProcessLoad.calculateProcessLoad(word, BACKRONYM, language);
        Log.d("TaskManager ", word + " - " + BACKRONYM + " - " + language + " - " + load);
        Log.d("File Name", language);
        boolean hasBackronym = false;

        String temp = "";
        for (int i = 1; i <= word.length(); i++)
            temp += word.charAt(word.length() - i);
        final String reverse = temp;

        InputStream in = null;
        try {
            in = context.getAssets().open(language);
        }
        catch(IOException ioe) {
            Log.e("task", ioe.getLocalizedMessage());
        }
        Scanner input = new Scanner(in);
        temp=null;
        while (input.hasNext()) {
            String e = input.nextLine();

            if (e == null || e.isEmpty()) {
                break;
            }

            if (reverse.equals(temp = e.toLowerCase())) {
                hasBackronym = true;
                break;
            }
            //if(reverse.charAt(0)< temp.charAt(0))
            //    break;

        }
        Log.d("LTE", "done backronym");
        synchronized (resultReady) {
            resultReady =true;
            return hasBackronym;
        }
    }

    @Override
    protected Object doInBackground(Object... objects) {
        startTime = new Date().getTime();
        if(searchOption.equals(BACKRONYM))
            return result = hasBackronym(word, language);
        if(searchOption.equals(ANAGRAM))
            return result = searchForAnagram(word, language).toArray(new String[0]);
        if(searchOption.equals(KANGAROO))
            return result = searchForKangaroo(word, language).toArray(new String[0]);

        return null;
    }

    @Override
    protected synchronized void onPostExecute(Object o) {

        Log.d("LTE", "==result ready");
        task.incrementTaskCompleted();
        if(isCancelled()) {
            Log.d("LTE", "========cancel");
            return;
        }
        TextView item = new TextView(context);
        item.setText(this.getTitle());
        item.setPadding(40, 0, 0, 0);
        item.setTextColor(Color.BLUE);
        item.setTextSize(15);
        task.getLayout().addView(item);

        if (o instanceof Boolean) {

            Boolean out = (Boolean) o;
            item = new TextView(context);
            item.setText("Has backronym? " + (out ? "Yes" : "No"));
            item.setPadding(40, 0, 0, 0);
            task.getLayout().addView(item);
            Log.d("LTE", "backronym added");
        } else {
            Log.d("LTE", o.getClass().getName());
            String[] out = (String[]) o;
            if(out == null || out.length==0) {
                item = new TextView(context);
                item.setText("Empty");
                item.setPadding(40, 0, 0, 0);
                item.setTextColor(Color.RED);
                //item.setBackgroundColor(Color.RED);
                task.getLayout().addView(item);
            }
            for (String s : out) {
                item = new TextView(context);
                item.setText(s);
                item.setPadding(40, 0, 0, 0);
                task.getLayout().addView(item);
            }
        }
        endTime = new Date().getTime();
        updateStats ();
        synchronized (task.getProgressBar()) {
            task.getProgressBar().incrementProgressBy((int)(1.0/task.getProcesses().size()*100));
            TextView txt = new TextView(task.getProgressBar().getContext());
            txt.setText(this.getTitle().toLowerCase()+" completed...");
            ((LinearLayout)task.getProgressBar().getParent())
                    .addView(txt,0);
        }
        if(task.isResultReady()) {
            Log.d("LTE", "==done");
            task.updateGUI();
        }

    }

    @Override
    public long getDuration() {
        return endTime - startTime;
    }

    @Override
    public boolean isResultReady() {
        return this.getStatus()==Status.FINISHED;
    }

    @Override
    public void abort() {
        this.cancel(true);
    }

    public  Object getResult() {
        try {
            return get();
        }catch (Exception ie) {
            return  null;
        }
    }

    private void updateStats () {
        int found = 0;
        try {
            //found = get() instanceof Boolean ? ((Boolean) get()) ? 1 : 0 : ((String[]) get()).length;
            if(get() instanceof Boolean) {
                Boolean val = (Boolean) get();
                if(val)
                    found = 1;
                else
                    found = 0;
            }
            else if(get() instanceof String[]) {
                String[] val = (String[])get();
                found = val.length;
            }

        }
        catch (InterruptedException e) {
            Log.d("LTE", "++++Cannnot update stats because of Interrupt exception");
            e.printStackTrace();
            return;
        } catch (ExecutionException e) {
            Log.d("LTE", "++++Cannnot update stats because of Execution Exception");
            e.printStackTrace();
            return;
        }
        org.petrove.wordsearch.Log.add(word, TaskManager.getLanguageName(language), searchOption, found,
                org.petrove.wordsearch.Log.Mode.LOCAL,
                this.getDuration(),
                ProcessLoad.calculateProcessLoad(word,searchOption,language),
                reason);

        Integer averageCount = null, specificCount = null, overallCount = null, overallAverageCount=null;
        Long averageTime = null, specificTime = null, overallTime = null, overallAverageTime;
        String overallKey = null, specificKey = null;

        if (searchOption.equals(ANAGRAM)) {
            specificKey = TaskManager.LOCAL_ANAGRAM;
            overallKey = TaskManager.OVERALL_ANAGRAM;
        } else if (searchOption.equals(KANGAROO)) {
            specificKey = TaskManager.LOCAL_KANGAROO;
            overallKey = TaskManager.OVERALL_KANGAROO;
        } else if (searchOption.equals(BACKRONYM)) {
            specificKey = TaskManager.LOCAL_BACKRONYM;
            overallKey = TaskManager.OVERALL_BACKRONYM;
        }
        synchronized (TaskManager.searchCount) {
            averageCount = TaskManager.searchCount.get(TaskManager.LOCAL_AVERAGE);
            if (averageCount == null)
                averageCount = 0;
            specificCount = TaskManager.searchCount.get(specificKey);
            if (specificCount == null)
                specificCount = 0;
            overallCount = TaskManager.searchCount.get(overallKey);
            if (overallCount == null)
                overallCount = 0;
            overallAverageCount = TaskManager.searchCount.get(TaskManager.OVERALL_AVERAGE);
            if (overallAverageCount == null)
                overallAverageCount = 0;

            averageTime = TaskManager.searchTime.get(TaskManager.LOCAL_AVERAGE);
            if (averageTime == null)
                averageTime = 0L;
            specificTime = TaskManager.searchTime.get(specificKey);
            if (specificTime == null)
                specificTime = 0L;
            overallTime = TaskManager.searchTime.get(overallKey);
            if (overallTime == null)
                overallTime = 0L;
            overallAverageTime = TaskManager.searchTime.get(TaskManager.OVERALL_AVERAGE);
            if (overallAverageTime == null)
                overallAverageTime = 0L;

            averageTime = (averageTime * averageCount++ + this.getDuration()) / averageCount;
            specificTime = (specificTime * specificCount++ + this.getDuration()) / specificCount;
            overallTime = (overallTime * overallCount++ + this.getDuration()) / overallCount;
            overallAverageTime = (overallAverageTime * overallAverageCount++ + this.getDuration()) / overallAverageCount;

            TaskManager.searchCount.put(specificKey, specificCount);
            TaskManager.searchCount.put(overallKey, overallCount);
            TaskManager.searchCount.put(TaskManager.LOCAL_AVERAGE, averageCount);
            TaskManager.searchCount.put(TaskManager.OVERALL_AVERAGE, overallAverageCount);

            TaskManager.searchTime.put(specificKey, specificTime);
            TaskManager.searchTime.put(overallKey, overallTime);
            TaskManager.searchTime.put(TaskManager.LOCAL_AVERAGE, averageTime);
            TaskManager.searchTime.put(TaskManager.OVERALL_AVERAGE, overallAverageTime);
        }
    }

    public String getTitle() {
        if(language.equals(TaskManager.ENGLISH)) {
            if(searchOption.equals(ANAGRAM))
                return ANAGRAM_EN;
            if(searchOption.equals(KANGAROO))
                return  KANGAROO_EN;
            if(searchOption.equals(BACKRONYM))
                return BACKRONYM_EN;
        }
        else if(language.equals(FRENCH)) {
            if(searchOption.equals(ANAGRAM))
                return ANAGRAM_FR;
            if(searchOption.equals(KANGAROO))
                return  KANGAROO_FR;
            if(searchOption.equals(BACKRONYM))
                return BACKRONYM_FR;
        }
        else if(language.equals(SPANISH)) {
            if(searchOption.equals(ANAGRAM))
                return ANAGRAM_ES;
            if(searchOption.equals(KANGAROO))
                return  KANGAROO_ES;
            if(searchOption.equals(BACKRONYM))
                return BACKRONYM_ES;
        }
        return null;
    }
}
