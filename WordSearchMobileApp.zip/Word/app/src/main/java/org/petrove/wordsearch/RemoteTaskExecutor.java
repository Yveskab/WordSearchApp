package org.petrove.wordsearch;

import android.content.Context;
import android.graphics.Color;
import android.os.AsyncTask;
import android.util.JsonReader;
import android.util.Log;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.ConnectException;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutionException;

import static org.petrove.wordsearch.TaskManager.ANAGRAM;
import static org.petrove.wordsearch.TaskManager.ANAGRAM_EN;
import static org.petrove.wordsearch.TaskManager.ANAGRAM_ES;
import static org.petrove.wordsearch.TaskManager.ANAGRAM_FR;
import static org.petrove.wordsearch.TaskManager.BACKRONYM;
import static org.petrove.wordsearch.TaskManager.BACKRONYM_EN;
import static org.petrove.wordsearch.TaskManager.BACKRONYM_ES;
import static org.petrove.wordsearch.TaskManager.BACKRONYM_FR;
import static org.petrove.wordsearch.TaskManager.KANGAROO;
import static org.petrove.wordsearch.TaskManager.KANGAROO_EN;
import static org.petrove.wordsearch.TaskManager.KANGAROO_ES;
import static org.petrove.wordsearch.TaskManager.KANGAROO_FR;

public class RemoteTaskExecutor extends AsyncTask<Object, Object, Object> implements Executor {
    private String word, searchOption, language, reason;
    private Context context;
    private Boolean result;
    private List<String> results;
    private Object returnValue;
    private Boolean resultReady;
    private long startTime, endTime;
    public static final String SERVICE_URL_STRING = "http://scolabs.com:8080/wordsearch/rs/wordsearch/";
    //public static String SERVICE_URL_STRING = "http://10.0.0.6:8080/wordsearch/rs/wordsearch/";
    private TaskManager task;
    public static final int CONNECTION_TIMEOUT = 3000;
    private boolean searchFailed = false;
    private String failReason;
    public RemoteTaskExecutor(Context context, String word, String option, String language, String reason, TaskManager task) {
        resultReady = false;
        Log.d("RTE", "RTE started");
        this.context = context;
        results = new ArrayList<String>();
        this.word = word;
        this.searchOption = option;
        if (language.equals(TaskManager.ENGLISH))
            this.language = "en";
        else if (language.equals(TaskManager.FRENCH))
            this.language = "fr";
        else if (language.equals(TaskManager.SPANISH))
            this.language = "es";
        else if (language.equals(TaskManager.PORTUGUESE))
            this.language = "pt";
        else
            this.language = "";
        this.reason = reason;
        this.task = task;
    }

    public  String getFileNameFromLanguage() {
        if (this.language.equals("en"))
            return TaskManager.ENGLISH;
        else if (language.equals("fr"))
            return TaskManager.FRENCH ;
        else if (language.equals("es"))
            return TaskManager.SPANISH;
        else if (language.equals("pt"))
            return TaskManager.PORTUGUESE;
        else
            return "";
    }
    public static String getLanguageName(String language) {
        if(language.equals("en"))
            return "English";
        if(language.equals("fr"))
            return "French";
        if(language.equals("es"))
            return "Spanish";
        if(language.equals("pt"))
            return "Portuguese";
        else
            return "";
    }
    protected Object doInBackground(Object... args) {
        startTime = new Date().getTime();
        try {
            Log.d("RTE", "starting doInBackround");

            String urlString = SERVICE_URL_STRING +
                    searchOption.toLowerCase() + "/" + this.language +
                    "/" + word;
            Log.d("RTE", "url string: " + urlString);
            URL webServiceURL = new URL(urlString);
            Log.d("RTE", "url created");
            URLConnection connection = webServiceURL.openConnection();
            connection.setConnectTimeout(3000);
            Reader reader = new InputStreamReader(
                    connection.getInputStream());
            Log.d("RTE", "reader created");
            // create a JsonReader from the Reader
            JsonReader serviceReader = new JsonReader(reader);
            Log.d("RTE", "jsonreader created");
            if (searchOption.equals(TaskManager.BACKRONYM)) {
                serviceReader.beginObject();
                serviceReader.nextName();
                result = serviceReader.nextBoolean();
                Log.d("RTE", "result: " + result);
                return result;
            } else {
                serviceReader.beginArray();
                while (serviceReader.hasNext()) {
                    serviceReader.beginObject();
                    serviceReader.nextName();
                    results.add(serviceReader.nextString());
                    serviceReader.endObject();
                }
                Log.d("RTE", "result: " + results);
                return results.toArray(new String[0]);
            }

        } // end try
        catch (MalformedURLException e) {
            Log.d("RTE", e.toString());
            this.searchFailed = true;
            this.failReason = "malformed URL";
        } // end catch
        catch (SocketTimeoutException ie) {
            Log.d("RTE", "==========time out");
            this.searchFailed = true;
            this.failReason = "server unavaiable";
        }
        catch (ConnectException ce) {
            Log.d("RTE", "========connection exception:"+ce);
            this.searchFailed = true;
            this.failReason = "connection error";
        }
        catch (IOException e) {
            Log.v("RTE", e.toString());
            this.searchFailed = true;
            this.failReason = "results could not be retrieved";
        } // end catch
        catch (IllegalStateException e) {
            Log.v("RTE", e.toString());
            this.searchFailed = true;
            this.failReason = "corrupted results";
        }



        return null;
    }

    @Override
    protected synchronized void onPostExecute(Object o) {
        Log.d("RTE", "==result ready" + o);
        task.incrementTaskCompleted();
        if(isCancelled()) {
            Log.d("RTE", "========cancel");
            return;
        }
        TextView item = new TextView(context);
        item.setText(this.getTitle());
        item.setPadding(40, 0, 0, 0);
        item.setTextColor(Color.BLUE);
        item.setTextSize(15);
        Log.d("RTE", "==title: " + this.task);
        task.getLayout().addView(item);

        if(searchFailed) {
            item = new TextView(context);
            item.setText("Error: "+this.failReason);
            item.setPadding(40, 0, 0, 0);
            item.setTextColor(Color.RED);
            task.getLayout().addView(item);
            Log.d("LTE", "backronym added");
        }
        else if (o instanceof Boolean) {
            Boolean out = (Boolean) o;
            item = new TextView(context);
            item.setText("Has backronym? " + (out ? "Yes" : "No"));
            item.setPadding(40, 0, 0, 0);
            task.getLayout().addView(item);
            Log.d("LTE", "backronym added");
        } else {
            Log.d("LTE", o.getClass().getName());
            String[] out = (String[]) o;
            if (out == null || out.length == 0) {
                item = new TextView(context);
                item.setText("Empty");
                item.setPadding(40, 0, 0, 0);
                //item.setBackgroundColor(Color.RED);
                item.setTextColor(Color.RED);
                task.getLayout().addView(item);
            }
            for (String s : out) {
                item = new TextView(context);
                item.setText(s);
                item.setPadding(40, 0, 0, 0);
                task.getLayout().addView(item);
            }
        }
        endTime = new Date().getTime();
        updateStats ();
        synchronized (task.getProgressBar()) {
            task.getProgressBar().incrementProgressBy((int)(1.0/task.getProcesses().size()*100));
            TextView txt = new TextView(task.getProgressBar().getContext());
            txt.setText(this.getTitle().toLowerCase()+" completed...");
            ((LinearLayout)task.getProgressBar().getParent())
                    .addView(txt,0);
        }
        if (task.isResultReady()) {
            Log.d("RTE", "==done");

            task.updateGUI();
        }



    }

    private void updateStats () {
        int found = 0;
        try {
            //found = get() instanceof Boolean ? ((Boolean) get()) ? 1 : 0 : ((String[]) get()).length;
            if(get() instanceof Boolean) {
                Boolean val = (Boolean) get();
                if(val)
                    found = 1;
                else
                    found = 0;
            }
            else if(get() instanceof String[]) {
                String[] val = (String[])get();
                found = val.length;
            }

        }
        catch (InterruptedException e) {
            Log.d("LTE", "++++Cannnot update stats because of Interrupt exception");
            e.printStackTrace();
            return;
        } catch (ExecutionException e) {
            Log.d("LTE", "++++Cannnot update stats because of Execution Exception");
            e.printStackTrace();
            return;
        }
        org.petrove.wordsearch.Log.add(word, getLanguageName(language), searchOption, found,
                org.petrove.wordsearch.Log.Mode.REMOTE,
                this.getDuration(),
                ProcessLoad.calculateProcessLoad(word,searchOption,getFileNameFromLanguage()),
                reason);
        Integer averageCount = null, specificCount = null, overallCount = null, overallAverageCount=null;
        Long averageTime = null, specificTime = null, overallTime = null, overallAverageTime;
        String overallKey = null, specificKey = null;

        if (searchOption.equals(ANAGRAM)) {
            specificKey = TaskManager.REMOTE_ANAGRAM;
            overallKey = TaskManager.OVERALL_ANAGRAM;
        } else if (searchOption.equals(KANGAROO)) {
            specificKey = TaskManager.REMOTE_KANGAROO;
            overallKey = TaskManager.OVERALL_KANGAROO;
        } else if (searchOption.equals(BACKRONYM)) {
            specificKey = TaskManager.REMOTE_BACKRONYM;
            overallKey = TaskManager.OVERALL_BACKRONYM;
        }
        synchronized (TaskManager.searchCount) {
            averageCount = TaskManager.searchCount.get(TaskManager.REMOTE_AVERAGE);
            if (averageCount == null)
                averageCount = 0;
            specificCount = TaskManager.searchCount.get(specificKey);
            if (specificCount == null)
                specificCount = 0;
            overallCount = TaskManager.searchCount.get(overallKey);
            if (overallCount == null)
                overallCount = 0;
            overallAverageCount = TaskManager.searchCount.get(TaskManager.OVERALL_AVERAGE);
            if (overallAverageCount == null)
                overallAverageCount = 0;

            averageTime = TaskManager.searchTime.get(TaskManager.REMOTE_AVERAGE);
            if (averageTime == null)
                averageTime = 0L;
            specificTime = TaskManager.searchTime.get(specificKey);
            if (specificTime == null)
                specificTime = 0L;
            overallTime = TaskManager.searchTime.get(overallKey);
            if (overallTime == null)
                overallTime = 0L;
            overallAverageTime = TaskManager.searchTime.get(TaskManager.OVERALL_AVERAGE);
            if (overallAverageTime == null)
                overallAverageTime = 0L;

            averageTime = (averageTime * averageCount++ + this.getDuration()) / averageCount;
            specificTime = (specificTime * specificCount++ + this.getDuration()) / specificCount;
            overallTime = (overallTime * overallCount++ + this.getDuration()) / overallCount;
            overallAverageTime = (overallAverageTime * overallAverageCount++ + this.getDuration()) / overallAverageCount;

            TaskManager.searchCount.put(specificKey, specificCount);
            TaskManager.searchCount.put(overallKey, overallCount);
            TaskManager.searchCount.put(TaskManager.REMOTE_AVERAGE, averageCount);
            TaskManager.searchCount.put(TaskManager.OVERALL_AVERAGE, overallAverageCount);

            TaskManager.searchTime.put(specificKey, specificTime);
            TaskManager.searchTime.put(overallKey, overallTime);
            TaskManager.searchTime.put(TaskManager.REMOTE_AVERAGE, averageTime);
            TaskManager.searchTime.put(TaskManager.OVERALL_AVERAGE, overallAverageTime);
        }
    }

    public Object getResult() {
        try {
            return get();
        } catch (Exception e) {
            return null;
        }
    }


    @Override
    public boolean isResultReady() {

        return this.getStatus()==Status.FINISHED;
    }

    @Override
    public long getDuration() {
        return endTime - startTime;
    }

    @Override
    public void abort() {
        this.cancel(true);
    }

    public String getTitle() {
        if (language.equals("en")) {
            if (searchOption.equals(ANAGRAM))
                return ANAGRAM_EN;
            if (searchOption.equals(KANGAROO))
                return KANGAROO_EN;
            if (searchOption.equals(BACKRONYM))
                return BACKRONYM_EN;
        } else if (language.equals("fr")) {
            if (searchOption.equals(ANAGRAM))
                return ANAGRAM_FR;
            if (searchOption.equals(KANGAROO))
                return KANGAROO_FR;
            if (searchOption.equals(BACKRONYM))
                return BACKRONYM_FR;
        } else if (language.equals("es")) {
            if (searchOption.equals(ANAGRAM))
                return ANAGRAM_ES;
            if (searchOption.equals(KANGAROO))
                return KANGAROO_ES;
            if (searchOption.equals(BACKRONYM))
                return BACKRONYM_ES;
        }
        return null;
    }



}
