package org.petrove.wordsearch;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.util.Log;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.concurrent.ExecutionException;

public class NetworkMonitor {
    private Context context;
    private ConnectivityManager connectivityManager;
    private NetworkInfo wifiManager;
    private NetworkInfo lteManager;
    public NetworkMonitor(Context context) {

        this.context = context;
        this.connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        this.wifiManager = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        lteManager = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
    }

    public boolean isNetworkConnected() {

        return this.wifiManager.isConnected() || lteManager.isConnected();
    }

    public boolean isServerAvailable() {
        AsyncTask<Void, Void, Boolean> checkServer = new AsyncTask<Void, Void, Boolean>() {
            @Override
            protected Boolean doInBackground(Void... voids) {
                try {

                    URL url = new URL(RemoteTaskExecutor.SERVICE_URL_STRING + "test");
                    URLConnection conn = url.openConnection();
                    conn.setConnectTimeout(3000);
                    conn.connect();


                } catch (Exception e) {
                    Log.d("RTE", "=====connect====" + e);
                    return false;
                }

                return true;
            }
        };
        checkServer.execute();
        try {
            return checkServer.get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
        return false;

    }

}
