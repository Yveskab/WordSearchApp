package org.petrove.wordsearch;

public interface Executor {
    boolean isResultReady();
    String getTitle();
    Object getResult();
    long getDuration();
    void abort();

}
