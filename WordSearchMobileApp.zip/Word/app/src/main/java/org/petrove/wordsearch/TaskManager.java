package org.petrove.wordsearch;

import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.io.StreamCorruptedException;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

public class TaskManager {
    public static final Map<String, Integer> searchCount = new HashMap<String, Integer>();
    public static final Map<String, Long> searchTime = new HashMap<String, Long>();
    public static final String LOCAL_ANAGRAM, LOCAL_KANGAROO, LOCAL_BACKRONYM, LOCAL_AVERAGE;
    public static final String REMOTE_ANAGRAM, REMOTE_KANGAROO, REMOTE_BACKRONYM, REMOTE_AVERAGE;
    public static final String OVERALL_ANAGRAM, OVERALL_KANGAROO, OVERALL_BACKRONYM, OVERALL_AVERAGE;
    public static final String SEARCH_COUNT_KEY = "SEARCH_COUNT_KEY", SEARCH_TIME_KEY = "SEARCH_TIME_KEY";
    public static final String DEFAULT_LOG_KEY = "defaultLog.txt";
    private String wifiRequired = "An active network connection is required to offload the task."
            + "\nPlease activate the WiFi or Mobile data, or uncheck the offload only option in the setting";
    private String serverUnavailable = "The server is unavailable. Uncheck the offload only "
            + "option if you want your search to run dynamically.";
    public static SharedPreferences searchCountPreferences, searchTimePreferences;

    static {


        LOCAL_ANAGRAM = "LOCAL_ANAGRAM";
        LOCAL_KANGAROO = "LOCAL_KANGAROO";
        LOCAL_BACKRONYM = "LOCAL_BACKRONYM";
        LOCAL_AVERAGE = "LOCAL_AVERAGE";

        REMOTE_ANAGRAM = "REMOTE_ANAGRAM";
        REMOTE_KANGAROO = "REMOTE_KANGAROO";
        REMOTE_BACKRONYM = "REMOTE_BACKRONYM";
        REMOTE_AVERAGE = "REMOTE_AVERAGE";

        OVERALL_ANAGRAM = "OVERALL_ANAGRAM";
        OVERALL_KANGAROO = "OVERALL_KANGAROO";
        OVERALL_BACKRONYM = "OVERALL_BACKRONYM";
        OVERALL_AVERAGE = "OVERALL_AVERAGE";
    }

    public static final String ANAGRAM_EN, ANAGRAM_FR, ANAGRAM_ES, ANAGRAM_PT;
    public static final String KANGAROO_EN, KANGAROO_FR, KANGAROO_ES,
            KANGAROO_PT;
    public static final String BACKRONYM_EN, BACKRONYM_FR, BACKRONYM_ES,
            BACKRONYM_PT;

    public final static String ENGLISH = "words.txt",
            FRENCH = "francais.txt",
            SPANISH = "espanol.txt",
            PORTUGUESE = "porto.txt";

    public final static String KANGAROO = "kangaroo",
            ANAGRAM = "anagram",
            BACKRONYM = "backronym";

    static {
        ANAGRAM_EN = "Anagram - English";
        ANAGRAM_FR = "Anagram - French";
        ANAGRAM_ES = "Anagram - Spanish";
        ANAGRAM_PT = "Anagram - Portuguese";
        KANGAROO_EN = "Kangaroo - English";
        KANGAROO_FR = "Kangaroo - French";
        KANGAROO_ES = "Kangaroo - Spanish";
        KANGAROO_PT = "Kangaroo - Portuguese";
        BACKRONYM_EN = "Backronym - English";
        BACKRONYM_FR = "Backronym - French";
        BACKRONYM_ES = "Backronym - Spanish";
        BACKRONYM_PT = "Backronym - Portuguese";
    }

    private String[] languages;
    private String[] searchOptions;
    private String word;
    private Context context;
    private LinkedList<Executor> tasks;
    private boolean hasStarted = false;
    private BatteryMonitor batteryMonitor;
    private MemoryMonitor memoryMonitor;
    private NetworkMonitor networkMonitor;
    private Dialog progressDialog, resultDialog, reportDialog, moreDetailDialog;
    ProgressBar progressBar;
    private LinearLayout layout;
    private int taskCompleted = 0;
    private long startTime, endTime;
    private static boolean offloadingAuthorized = true;
    private static boolean offloadOnly = false;

    public TaskManager(String word, String[] languages,
                       String[] searchOptions,
                       Context c,
                       Dialog progressDialog,
                       ProgressBar progressBar,
                       Dialog resultDialog,
                       LinearLayout layout) {
        tasks = new LinkedList<Executor>();
        this.word = word;
        this.languages = languages;
        this.searchOptions = searchOptions;
        context = c;

        batteryMonitor = new BatteryMonitor(context);
        memoryMonitor = new MemoryMonitor(context);
        networkMonitor = new NetworkMonitor(context);

        this.layout = layout;
        this.resultDialog = resultDialog;
        this.progressDialog = progressDialog;
        this.progressBar = progressBar;
        this.resultDialog.setCancelable(false);
        startTime = new java.util.Date().getTime();
        loadStats(context);
    }

    public ProgressBar getProgressBar() {
        return progressBar;
    }

    public static void loadDefLog(Context context) {
        try {

            FileInputStream input;
            ObjectInputStream in = new ObjectInputStream(input = context.openFileInput(DEFAULT_LOG_KEY));
            org.petrove.wordsearch.Log defLog = (org.petrove.wordsearch.Log) in.readObject();
            Log.d("TaskManager", "reading: " + defLog);
            org.petrove.wordsearch.Log.setDefault(defLog);
            Log.d("TaskManager", "read successfull");
            in.close();
            input.close();
        } catch (FileNotFoundException e) {
            Log.d("Tast", "fail to read");
            e.printStackTrace();
        } catch (StreamCorruptedException e) {
            Log.d("Tast", "fail to read");
            e.printStackTrace();
        } catch (IOException e) {
            Log.d("Tast", "fail to read");
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            Log.d("Tast", "fail to read");
            e.printStackTrace();
        }

    }

    public static void loadStats(Context context) {
        searchCountPreferences = context.getSharedPreferences(SEARCH_COUNT_KEY, Context.MODE_PRIVATE);
        searchTimePreferences = context.getSharedPreferences(SEARCH_TIME_KEY, Context.MODE_PRIVATE);


        Map<String, ?> map = searchCountPreferences.getAll();
        Set<String> keys = searchCountPreferences.getAll().keySet();
        for (String key : keys)
            searchCount.put(key, (Integer) map.get(key));
        map = searchTimePreferences.getAll();
        keys = searchTimePreferences.getAll().keySet();
        for (String key : keys)
            searchTime.put(key, (Long) map.get(key));
        Log.d("RTE", "downloaded count: " + searchCount);
        Log.d("RTE", "downloaded time: " + searchTime);
    }

    public static void persistDefaultLog(Context context) {
        try {
            FileOutputStream output;
            ObjectOutputStream out = new ObjectOutputStream(
                    output = context.openFileOutput(DEFAULT_LOG_KEY, Context.MODE_PRIVATE));
            out.writeObject(org.petrove.wordsearch.Log.defaultLog());
            out.close();
            output.flush();
            output.close();
            Log.d("TaskManager", "=====log saved " + org.petrove.wordsearch.Log.defaultLog());

        } catch (IOException e) {
            Log.d("TaskManager", "=====couldn't save log");
            e.printStackTrace();
        }
    }

    public void persisteMaps() {
        Log.d("RTE", "downloaded count: " + searchCount);
        Log.d("RTE", "downloaded time: " + searchTime);
        SharedPreferences.Editor map = searchCountPreferences.edit();
        Set<String> keys = searchCount.keySet();
        for (String key : keys)
            map.putInt(key, searchCount.get(key));
        map.commit();

        map = searchTimePreferences.edit();
        keys = searchTime.keySet();
        for (String key : keys)
            map.putLong(key, searchTime.get(key));
        map.commit();
    }

    public static String getLanguageName(String fileName) {
        if (fileName.equals(ENGLISH))
            return "English";
        if (fileName.equals(FRENCH))
            return "French";
        if (fileName.equals(SPANISH))
            return "Spanish";
        if (fileName.equals(PORTUGUESE))
            return "Portuguese";
        return null;
    }

    public static boolean isOffloadingAuthorized() {
        return offloadingAuthorized;
    }

    public static void setOffloadingAuthorized(boolean offloadingAuthorized) {
        TaskManager.offloadingAuthorized = offloadingAuthorized;
    }

    public static boolean isOffloadOnly() {
        return offloadOnly;
    }

    public static void setOffloadOnly(boolean offloadOnly) {
        TaskManager.offloadOnly = offloadOnly;
    }

    public void incrementTaskCompleted() {
        ++taskCompleted;
    }

    public boolean isResultReady() {
        return taskCompleted == getProcesses().size();
    }

    public void updateGUI() {
        endTime = new Date().getTime();
        LinearLayout buttonLayout = (LinearLayout) LayoutInflater.from(context).inflate(R.layout.button_layout, null);
        buttonLayout.setPadding(40, 0, 15, 0);
        Button back = (Button) buttonLayout.findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resultDialog.dismiss();
            }
        });
        Button report = (Button) buttonLayout.findViewById(R.id.report);
        report.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("RTE", "task ready to create report");
                createReportDialog();
                Log.d("RTE", "task ready to show report");
                reportDialog.setCancelable(false);
                reportDialog.show();

            }
        });
        layout.addView(buttonLayout);
        progressDialog.dismiss();
        resultDialog.show();
        persisteMaps();

    }

    public int getTaskCompleted() {
        return taskCompleted;
    }

    public Dialog getProgressDialog() {
        return progressDialog;
    }

    public LinearLayout getLayout() {
        return layout;
    }

    public LinkedList<Executor> getProcesses() {
        return tasks;
    }

    public boolean hasStarted() {
        return hasStarted;
    }

    public Dialog createNoRunDialog(String content) {
        Dialog d = new Dialog(context);
        d.setTitle("Search Failed");
        //LinearLayout layout = new LinearLayout(d.getContext());
        TextView comment = new TextView(d.getContext());
        comment.setText(content);
        d.setContentView(comment);
        return d;
    }

    public void execute() {
        Log.d("TaskManager", "has enough memory: " + memoryMonitor.hasEnoughMemory());
        Log.d("TaskManager", "battery is low: " + batteryMonitor.batteryIsLow());
        Log.d("TaskManager", "is Wifi connected: " + networkMonitor.isNetworkConnected());
        Log.d("TaskManager", "is server available: " + networkMonitor.isServerAvailable());
        //runAllLocally();
        Dialog noRunDialog;

        if (!TaskManager.isOffloadingAuthorized()) {
            Log.d("TaskManager", "from no offloading authorized running all locally...");
            runAllLocally("Offloading not authorized");
            return;
        }

        if (!networkMonitor.isNetworkConnected()) {
            if (TaskManager.isOffloadOnly()) {
                noRunDialog = createNoRunDialog(wifiRequired);
                noRunDialog.show();
                progressDialog.dismiss();
                return;
            } else {
                Log.d("TaskManager", "from no wifi running all locally...");
                runAllLocally("No network connectivity");
                return;
            }
        }

        if (!networkMonitor.isServerAvailable()) {

            if (TaskManager.isOffloadOnly()) {
                noRunDialog = createNoRunDialog(serverUnavailable);
                noRunDialog.show();
                progressDialog.dismiss();
                return;
            } else {
                Log.d("TaskManager", "from server unavailable running all locally...");
                runAllLocally("Server unavailable");
                return;
            }
        }

        if (TaskManager.isOffloadOnly()) {
            Log.d("TaskManager", "running remotely...");
            runAllRemotelly("Offload only selected");
            return;
        }

        if (batteryMonitor.batteryIsLow()) {
            Log.d("TaskManager", "running remotely...");
            runAllRemotelly("Low battery");
            return;
        } else {
            Log.d("TaskManager", "running all normally...");
            runNormally();
            return;
        }
    }

    protected void runAllLocally(String reason) {
        for (String language : languages)
            for (String option : searchOptions) {
                LocalTaskExecutor executor = new LocalTaskExecutor(word, language, option, reason, context, this);
                executor.execute();
                tasks.add(executor);
            }
        hasStarted = true;
    }

    protected void runAllRemotelly(String reason) {
        for (String language : languages)
            for (String option : searchOptions) {
                RemoteTaskExecutor executor = new RemoteTaskExecutor(context, word, option, language, reason, this);
                tasks.add(executor);
                executor.execute();

            }
        hasStarted = true;

    }

    protected void runNormally() {
        for (String language : languages)
            for (String option : searchOptions) {
                if (ProcessLoad.calculateProcessLoad(word, option, language) > ProcessLoad.HEAVY_LOAD) {
                    RemoteTaskExecutor executor = new RemoteTaskExecutor(context, word, option, language, "High process load", this);
                    tasks.add(executor);
                    executor.execute();
                } else {
                    Log.d("TaskManager", "executing process locally......");
                    LocalTaskExecutor executor = new LocalTaskExecutor(word, language, option, "Low process load", context, this);
                    executor.execute();
                    tasks.add(executor);
                }
            }
        hasStarted = true;
    }

    public void createReportDialog() {
        reportDialog = new Dialog(context);
        reportDialog.setCancelable(false);
        LinearLayout dialogLayout = new LinearLayout(reportDialog.getContext());
        dialogLayout.setOrientation(LinearLayout.VERTICAL);
        reportDialog.setContentView(dialogLayout);
        reportDialog.setTitle("Search report");

        TextView item = new TextView(dialogLayout.getContext());
        item.setText("Word");
        item.setPadding(40, 0, 0, 0);
        item.setTextColor(Color.BLUE);
        item.setTextSize(15);
        dialogLayout.addView(item);

        item = new TextView(dialogLayout.getContext());
        item.setText(word);
        item.setPadding(40, 0, 0, 0);
        dialogLayout.addView(item);

        item = new TextView(dialogLayout.getContext());
        item.setText("Language(s)");
        item.setPadding(40, 0, 0, 0);
        item.setTextColor(Color.BLUE);
        item.setTextSize(15);
        dialogLayout.addView(item);

        for (String s : languages) {
            item = new TextView(dialogLayout.getContext());
            item.setText(getLanguageName(s));
            item.setPadding(40, 0, 0, 0);
            dialogLayout.addView(item);
        }

        item = new TextView(dialogLayout.getContext());
        item.setText("Option(s)");
        item.setPadding(40, 0, 0, 0);
        item.setTextColor(Color.BLUE);
        item.setTextSize(15);
        dialogLayout.addView(item);

        for (String s : searchOptions) {
            item = new TextView(dialogLayout.getContext());
            item.setText(s);
            item.setPadding(40, 0, 0, 0);
            dialogLayout.addView(item);
        }

        item = new TextView(dialogLayout.getContext());
        item.setText("Total running time");
        item.setPadding(40, 0, 0, 0);
        item.setTextColor(Color.BLUE);
        item.setTextSize(15);
        dialogLayout.addView(item);

        item = new TextView(dialogLayout.getContext());
        item.setText(((endTime - startTime) / 1000.0) + " sec");
        item.setPadding(40, 0, 0, 0);
        dialogLayout.addView(item);

        LinearLayout buttonLayout = (LinearLayout) LayoutInflater.from(context).inflate(R.layout.button_layout, null);
        buttonLayout.setPadding(40, 0, 15, 0);
        Button back = (Button) buttonLayout.findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                reportDialog.dismiss();
            }
        });
        Button report = (Button) buttonLayout.findViewById(R.id.report);
        report.setText("More details");
        report.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createMoreDetailDialog();
                //moreDetailDialog.setCancelable(false);
                moreDetailDialog.show();
            }
        });
        dialogLayout.addView(buttonLayout);

    }

    public void createMoreDetailDialog() {
        moreDetailDialog = new Dialog(context);
        ScrollView scroll = new ScrollView(moreDetailDialog.getContext());
        moreDetailDialog.setContentView(scroll);
        LinearLayout dialogLayout = new LinearLayout(moreDetailDialog.getContext());
        dialogLayout.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(dialogLayout);
        moreDetailDialog.setTitle("More details");

        for (Executor task : tasks) {
            TextView item = new TextView(dialogLayout.getContext());
            item.setText(task.getTitle());
            item.setPadding(40, 0, 0, 0);
            item.setTextColor(Color.BLUE);
            item.setTextSize(15);
            dialogLayout.addView(item);

            LinearLayout labelLayout = (LinearLayout) LayoutInflater.from(context).inflate(R.layout.label_layout, null);
            labelLayout.setPadding(40, 0, 15, 0);
            TextView name = (TextView) labelLayout.findViewById(R.id.nameLabel);
            name.setText("Duration: ");

            TextView value = (TextView) labelLayout.findViewById(R.id.valueLabel);
            value.setText("" + (task.getDuration() / 1000.0 + " sec"));
            dialogLayout.addView(labelLayout);

            labelLayout = (LinearLayout) LayoutInflater.from(moreDetailDialog.getContext()).inflate(R.layout.label_layout, null);
            labelLayout.setPadding(40, 0, 15, 0);
            name = (TextView) labelLayout.findViewById(R.id.nameLabel);
            name.setText("Mode: ");
            String mode = task instanceof LocalTaskExecutor ? "Local" : "Remote";

            value = (TextView) labelLayout.findViewById(R.id.valueLabel);
            value.setText(mode);
            dialogLayout.addView(labelLayout);

            labelLayout = (LinearLayout) LayoutInflater.from(moreDetailDialog.getContext()).inflate(R.layout.label_layout, null);
            labelLayout.setPadding(40, 0, 15, 0);
            name = (TextView) labelLayout.findViewById(R.id.nameLabel);
            name.setText("Found: ");
            Object result = task.getResult();
            result = result instanceof String[] ? ((String[]) result).length : result;
            value = (TextView) labelLayout.findViewById(R.id.valueLabel);
            value.setText(result.toString());
            dialogLayout.addView(labelLayout);
        }
    }

    public static class MapWrapper implements Serializable {
        public MapWrapper(Map<String, ? extends Number> map) {
            this.map = map;
        }

        public MapWrapper() {
        }

        private Map<String, ? extends Number> map;

        public Map<String, ? extends Number> getMap() {
            return map;
        }

        public void setMap(Map<String, ? extends Number> map) {
            this.map = map;
        }
    }
}
