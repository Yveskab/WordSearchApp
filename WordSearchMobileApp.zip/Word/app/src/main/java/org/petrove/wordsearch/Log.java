package org.petrove.wordsearch;

import android.os.Bundle;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

public class Log implements Serializable{
    private static Log defaultLog;
    private List<Entry> entryList;
    static void setDefault(Log defaultLog) {
        android.util.Log.d("TaskManager", "======log read " + defaultLog);
        Log.defaultLog = defaultLog;
    }
    public  static Log newInstance() {
        return new Log();
    }

    public static boolean add(Entry entry) {
        return defaultLog().entryList.add(entry);
    }

    public static boolean add(String word,
                              String language,
                              String searchOption,
                              int found,
                              Mode mode,
                              long timeInMilli,
                              int load,
                              String reason) {

        return defaultLog().entryList.add(new Entry(word,language,searchOption,found,mode,timeInMilli,load,reason));
    }
    public static Log defaultLog() {
        return defaultLog == null? defaultLog = newInstance():defaultLog;
    }

    public List<Entry> entryList() {
        return this.entryList;
    }
    private Log() {
        entryList = new LinkedList<Entry>();
    }

    public static enum Mode {
        REMOTE, LOCAL;
    }

    @Override
    public String toString() {
        return "Log { entryList"+entryList+"}";
    }

    public static class Entry implements Serializable{
        private String word, language, searchOption;
        private int found;
        private Mode mode;
        private long timeInMilli;
        private int load;
        private String reason;

        public Entry() {
        }

        public Entry(String word,
                     String language,
                     String searchOption,
                     int found, Mode mode,
                     long timeInMilli,
                     int load,
                     String reason) {
            this.word = word;
            this.language = language;
            this.searchOption = searchOption;
            this.found = found;
            this.mode = mode;
            this.timeInMilli = timeInMilli;
            this.load = load;
            this.reason = reason;
        }

        public String getWord() {
            return word;
        }

        public void setWord(String word) {
            this.word = word;
        }

        public Mode getMode() {
            return mode;
        }

        public void setMode(Mode mode) {
            this.mode = mode;
        }

        public String getLanguage() {
            return language;
        }

        public void setLanguage(String language) {
            this.language = language;
        }

        public String getSearchOption() {
            return searchOption;
        }

        public void setSearchOption(String searchOption) {
            this.searchOption = searchOption;
        }

        public int getFound() {
            return found;
        }

        public void setFound(int found) {
            this.found = found;
        }

        public long getTimeInMilli() {
            return timeInMilli;
        }

        public void setTimeInMilli(long timeInMilli) {
            this.timeInMilli = timeInMilli;
        }

        public int getLoad() {
            return load;
        }

        public void setLoad(int load) {
            this.load = load;
        }

        public String getReason() {
            return reason;
        }

        public void setReason(String reason) {
            this.reason = reason;
        }

        @Override
        public String toString() {
            return "Entry{" +
                    "word='" + word + '\'' +
                    ", mode=" + mode +
                    ", timeInMilli=" + timeInMilli +
                    ", load=" + load +
                    ", reason='" + reason + '\'' +
                    '}';
        }
    }
}
